"""
config.py
---------
Centralized, typed application settings loaded from environment variables (.env).

Using pydantic-settings ensures:
  - Fail-fast startup if required secrets are missing.
  - No secret ever hardcoded in source.
  - Single source of truth imported across routers/services.
"""

from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # --- App ---
    app_env: str = "development"
    app_secret_key: str
    api_v1_prefix: str = "/api/v1"
    cors_origins: str = "http://localhost:3000"

    # --- Database ---
    database_url: str

    # --- Authentication (Firebase Admin SDK) ---
    firebase_service_account_path: str = "./firebase_key.json"

    # --- Rate limiting (slowapi; Redis in production, memory:// for local dev) ---
    redis_url: str = "memory://"

    # --- Field-level encryption (AES-256-GCM via Fernet) for phone numbers etc. ---
    # Generate with: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
    field_encryption_key: str

    # --- NVIDIA NIM / Nemotron ---
    nvidia_api_key: str
    nvidia_base_url: str = "https://integrate.api.nvidia.com/v1"
    nvidia_model_primary: str = "nvidia/nemotron-3.5-lightning-30b-a3b"
    nvidia_model_fallback: str = "nvidia/llama-3.1-nemotron-70b-instruct"
    nvidia_request_timeout_seconds: int = 30

    # --- Twilio ---
    twilio_account_sid: str
    twilio_auth_token: str
    twilio_from_number: str

    # --- Uploads ---
    upload_dir: str = "./uploads"
    max_upload_mb: int = 15

    # --- OCR ---
    tesseract_cmd: str = "/usr/bin/tesseract"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def cors_origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    """Cached settings singleton — avoids re-parsing .env on every import."""
    return Settings()
