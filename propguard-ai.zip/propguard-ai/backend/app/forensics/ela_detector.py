"""
ela_detector.py
----------------
Error Level Analysis (ELA) forensics for scanned property documents.

ELA works by re-saving an image at a known JPEG quality and diffing it against
the original. Regions that were edited/pasted after the last real save tend to
"error" at a different rate than untouched regions, so they light up in the
diff. It is a classic, well-understood signal for spotting:
  - Copy-pasted signatures / stamps
  - Digitally altered text (survey numbers, dates, amounts)
  - Recompressed/re-inserted regions

This is a *heuristic* signal, not proof of forgery — it is combined with OCR
+ Nemotron legal reasoning downstream for a final fraud score.

Also inspects EXIF metadata for anomalies (missing camera data on a supposed
photo, software-editing tags like Photoshop/GIMP, mismatched timestamps).
"""

from __future__ import annotations

import io
import os
from dataclasses import dataclass, field

import cv2
import numpy as np
from PIL import Image, ImageChops, ExifTags


# Software signatures commonly left behind by image editors — a strong
# signal (though not definitive) that a "scanned document" was touched
# in a raster editor after scanning.
EDITING_SOFTWARE_MARKERS = (
    "photoshop", "gimp", "affinity", "lightroom", "snapseed",
    "canva", "pixlr", "picsart",
)


@dataclass
class ELAResult:
    ela_score: float                     # 0-100 normalized suspicion score
    heatmap_path: str | None             # path to saved heatmap PNG
    mean_diff: float                     # raw mean pixel diff
    max_diff: int                        # raw max pixel diff
    hotspot_regions: list[dict] = field(default_factory=list)  # bounding boxes of high-error areas
    exif_anomalies: list[str] = field(default_factory=list)


class ELADetector:
    """
    Usage:
        detector = ELADetector(quality=90, resave_scale=15)
        result = detector.analyze("uploads/deed_123.jpg", heatmap_dir="uploads/heatmaps")
    """

    def __init__(self, quality: int = 90, resave_scale: int = 15, hotspot_threshold: int = 45):
        # `quality`: JPEG re-save quality used for the ELA baseline.
        # `resave_scale`: multiplier applied to the diff to make it visible.
        # `hotspot_threshold`: pixel intensity (0-255) above which a region
        #   is flagged as a "hotspot" candidate for tampering.
        self.quality = quality
        self.resave_scale = resave_scale
        self.hotspot_threshold = hotspot_threshold

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze(self, image_path: str, heatmap_dir: str | None = None) -> ELAResult:
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image not found: {image_path}")

        original = Image.open(image_path).convert("RGB")

        ela_image, mean_diff, max_diff = self._compute_ela(original)
        hotspots = self._find_hotspots(ela_image)
        score = self._score_from_diff(mean_diff, max_diff, hotspots)
        exif_anomalies = self._inspect_exif(image_path)

        heatmap_path = None
        if heatmap_dir:
            heatmap_path = self._save_heatmap(ela_image, image_path, heatmap_dir)

        return ELAResult(
            ela_score=round(score, 2),
            heatmap_path=heatmap_path,
            mean_diff=round(mean_diff, 4),
            max_diff=max_diff,
            hotspot_regions=hotspots,
            exif_anomalies=exif_anomalies,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _compute_ela(self, original: Image.Image) -> tuple[Image.Image, float, int]:
        """Re-save the image at a fixed JPEG quality and diff against original."""
        buffer = io.BytesIO()
        original.save(buffer, "JPEG", quality=self.quality)
        buffer.seek(0)
        resaved = Image.open(buffer)

        diff = ImageChops.difference(original, resaved)
        diff_np = np.array(diff)

        extrema = diff.getextrema()
        max_diff = max(channel[1] for channel in extrema) or 1
        scale = min(255.0 / max_diff, self.resave_scale)

        # Amplify the diff so subtle edits become visually/numerically obvious.
        amplified = np.clip(diff_np.astype(np.float32) * scale, 0, 255).astype(np.uint8)
        ela_image = Image.fromarray(amplified)

        mean_diff = float(diff_np.mean())
        return ela_image, mean_diff, int(max_diff)

    def _find_hotspots(self, ela_image: Image.Image) -> list[dict]:
        """Use OpenCV contour detection to bound high-error regions (likely tamper zones)."""
        gray = cv2.cvtColor(np.array(ela_image), cv2.COLOR_RGB2GRAY)
        _, thresh = cv2.threshold(gray, self.hotspot_threshold, 255, cv2.THRESH_BINARY)

        # Close small gaps so a tampered region reads as one contour, not many specks.
        kernel = np.ones((5, 5), np.uint8)
        closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        hotspots = []
        img_area = gray.shape[0] * gray.shape[1]
        for cnt in contours:
            area = cv2.contourArea(cnt)
            # Ignore tiny noise specks (<0.15% of image) and near-full-image
            # contours (likely a scan border artifact, not tampering).
            if area < img_area * 0.0015 or area > img_area * 0.6:
                continue
            x, y, w, h = cv2.boundingRect(cnt)
            hotspots.append({"x": int(x), "y": int(y), "width": int(w), "height": int(h),
                              "area_pct": round(100 * area / img_area, 3)})

        # Keep the top 10 largest hotspots to avoid noisy payloads.
        hotspots.sort(key=lambda h: h["area_pct"], reverse=True)
        return hotspots[:10]

    def _score_from_diff(self, mean_diff: float, max_diff: int, hotspots: list[dict]) -> float:
        """
        Heuristic 0-100 fraud-suspicion score.
        This is intentionally conservative — it feeds Nemotron as one signal
        among several, not a standalone verdict.
        """
        base = min(mean_diff * 4.0, 60.0)              # global error contributes up to 60 pts
        hotspot_bonus = min(len(hotspots) * 6.0, 30.0)  # localized tamper zones contribute up to 30 pts
        intensity_bonus = min(max_diff / 255 * 10.0, 10.0)
        return min(base + hotspot_bonus + intensity_bonus, 100.0)

    def _inspect_exif(self, image_path: str) -> list[str]:
        anomalies: list[str] = []
        try:
            img = Image.open(image_path)
            exif_raw = img.getexif()
            if not exif_raw:
                anomalies.append("No EXIF metadata present (common for screenshots or stripped scans).")
                return anomalies

            exif = {ExifTags.TAGS.get(k, k): v for k, v in exif_raw.items()}

            software = str(exif.get("Software", "")).lower()
            if any(marker in software for marker in EDITING_SOFTWARE_MARKERS):
                anomalies.append(f"Image processed with editing software: '{exif.get('Software')}'.")

            if "DateTimeOriginal" in exif and "DateTime" in exif:
                if exif["DateTimeOriginal"] != exif["DateTime"]:
                    anomalies.append("Capture timestamp and modification timestamp differ.")

            if "DateTime" not in exif and "DateTimeOriginal" not in exif:
                anomalies.append("No timestamp metadata found.")

        except Exception as exc:  # noqa: BLE001 — we want to surface any EXIF read failure as an anomaly, not crash the audit
            anomalies.append(f"EXIF inspection failed: {exc}")

        return anomalies

    def _save_heatmap(self, ela_image: Image.Image, original_path: str, heatmap_dir: str) -> str:
        os.makedirs(heatmap_dir, exist_ok=True)
        base_name = os.path.splitext(os.path.basename(original_path))[0]
        out_path = os.path.join(heatmap_dir, f"{base_name}_ela_heatmap.png")

        # Apply a false-color map so hotspots are visually obvious (red = high error).
        gray = cv2.cvtColor(np.array(ela_image), cv2.COLOR_RGB2GRAY)
        colored = cv2.applyColorMap(gray, cv2.COLORMAP_JET)
        cv2.imwrite(out_path, colored)
        return out_path
