"""
main.py
--------
PropGuard AI — FastAPI backend entrypoint.

Wires together:
  - App lifecycle (DB init on startup)
  - CORS for the Flutter mobile client
  - Module 1: /api/v1/property/audit         (real estate scam detector)
  - Module 2: /api/v1/interceptor/scan        (WhatsApp/SMS spam interceptor)
  - Module 3: /api/v1/sos/trigger             (women's safety SOS dispatcher)

Run locally:
    uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

The NVIDIA NIM client is configured once in `app/services/nemotron_client.py`
using the OpenAI-compatible SDK:

    AsyncOpenAI(
        base_url="https://integrate.api.nvidia.com/v1",
        api_key=settings.nvidia_api_key,   # loaded from .env — never hardcoded
    )
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from app.auth import init_firebase, limiter
from app.config import get_settings
from app.database import init_db
from app.routers import interceptor, property, sos, users

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("propguard.main")
settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # --- Startup ---
    logger.info("Starting PropGuard AI backend in '%s' mode", settings.app_env)
    init_firebase()
    logger.info("Firebase Admin SDK ready — JWT verification is live.")
    if settings.app_env == "development":
        # Dev convenience only — use Alembic migrations in production.
        await init_db()
        logger.info("Database tables ensured (dev mode).")
    yield
    # --- Shutdown ---
    logger.info("Shutting down PropGuard AI backend.")


app = FastAPI(
    title="PropGuard AI",
    description=(
        "Civic safety platform combining real-estate scam detection, "
        "WhatsApp/SMS spam interception, and women's physical safety SOS. "
        "All endpoints under /api/v1 (except /health) require a valid "
        "Firebase Bearer JWT — see Authorize button below."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

# --- CORS ---
# In production, terminate TLS 1.3 at the load balancer/ingress in front of
# this service (e.g. an HTTPS-only ALB/Cloud Run) so every hop is encrypted,
# per the PRD's "Enforce HTTPS/TLS 1.3 for all client-to-backend requests".
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Rate limiting (slowapi, Redis-backed) ---
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """
    Catch-all so an unexpected error (e.g. a Nemotron/Twilio outage) returns
    a clean 500 JSON body instead of leaking a stack trace to the mobile app.
    """
    logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "An unexpected error occurred. Please try again."},
    )


@app.get("/health", tags=["System"])
async def health_check():
    """Lightweight liveness probe for load balancers / uptime monitors."""
    return {"status": "ok", "service": "propguard-ai-backend", "env": settings.app_env}


# --- Register routers under /api/v1 ---
app.include_router(users.router, prefix=settings.api_v1_prefix)
app.include_router(property.router, prefix=settings.api_v1_prefix)
app.include_router(interceptor.router, prefix=settings.api_v1_prefix)
app.include_router(sos.router, prefix=settings.api_v1_prefix)
