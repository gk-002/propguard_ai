"""
models.py
---------
SQLAlchemy ORM models for PropGuard AI.

Tables:
  - User             : platform account, holds emergency contacts for SOS.
  - PropertyAudit     : Module 1 — real estate scam detection results.
  - InterceptedSpam    : Module 2 — WhatsApp/SMS interceptor log.
  - SOSLog            : Module 3 — women's safety SOS trigger events.
"""

import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


# ----------------------------------------------------------------------
# Enums
# ----------------------------------------------------------------------

class RiskLevel(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class SOSStatus(str, enum.Enum):
    TRIGGERED = "TRIGGERED"
    SMS_SENT = "SMS_SENT"
    SMS_FAILED = "SMS_FAILED"
    RESOLVED = "RESOLVED"


# ----------------------------------------------------------------------
# User
# ----------------------------------------------------------------------

class User(Base):
    """
    Identity is owned by Firebase Auth, not this table. `id` is the Firebase
    `uid` claim from the verified JWT (see app/auth.py) — there is no local
    password hash to manage or leak. This row exists to hold PropGuard-
    specific profile data (emergency contacts, audit history FKs).
    """
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(128), primary_key=True)  # Firebase uid
    full_name: Mapped[str] = mapped_column(String(120), nullable=False)
    email: Mapped[str | None] = mapped_column(String(255), unique=True, index=True, nullable=True)
    # Encrypted at rest (AES-256 via app.security.encryption) since it's PII.
    phone_number_encrypted: Mapped[str | None] = mapped_column(String(500), unique=True, nullable=True)

    # JSON list of {"name": str, "phone": "<AES-256 ciphertext>"} — phone
    # numbers are individually encrypted before this list is persisted;
    # see app.security.encryption.encrypt_contacts / decrypt_contacts.
    emergency_contacts: Mapped[list] = mapped_column(JSON, default=list)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

    property_audits: Mapped[list["PropertyAudit"]] = relationship(back_populates="owner")
    spam_events: Mapped[list["InterceptedSpam"]] = relationship(back_populates="owner")
    sos_logs: Mapped[list["SOSLog"]] = relationship(back_populates="owner")


# ----------------------------------------------------------------------
# Module 1 — Real Estate Scam Detector
# ----------------------------------------------------------------------

class PropertyAudit(Base):
    __tablename__ = "property_audits"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(128), ForeignKey("users.id"), nullable=False, index=True)

    original_filename: Mapped[str] = mapped_column(String(255))
    stored_path: Mapped[str] = mapped_column(String(500))
    document_type: Mapped[str] = mapped_column(String(50))  # title_deed | noc | sale_agreement | other

    # --- Forensics output (ELA) ---
    ela_score: Mapped[float] = mapped_column(Float, default=0.0)      # 0-100, higher = more suspicious
    ela_heatmap_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    exif_anomalies: Mapped[list] = mapped_column(JSON, default=list)

    # --- OCR extracted fields ---
    extracted_text: Mapped[str] = mapped_column(Text, default="")
    owner_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    survey_number: Mapped[str | None] = mapped_column(String(100), nullable=True)
    deed_date: Mapped[str | None] = mapped_column(String(50), nullable=True)
    stamp_duty_value: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # --- Nemotron legal reasoning output ---
    fraud_risk_score: Mapped[float] = mapped_column(Float, default=0.0)  # 0-100
    risk_level: Mapped[RiskLevel] = mapped_column(Enum(RiskLevel), default=RiskLevel.LOW)
    legal_red_flags: Mapped[list] = mapped_column(JSON, default=list)
    ai_summary: Mapped[str] = mapped_column(Text, default="")
    raw_model_response: Mapped[dict] = mapped_column(JSON, default=dict)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

    owner: Mapped["User"] = relationship(back_populates="property_audits")


# ----------------------------------------------------------------------
# Module 2 — WhatsApp / SMS Spam Interceptor
# ----------------------------------------------------------------------

class InterceptedSpam(Base):
    """
    Privacy note (PRD NFR): raw WhatsApp/SMS chat text must never be stored
    persistently. The full `message_text` is held only in ephemeral memory
    for the duration of the /interceptor/scan request (local keyword check
    + Nemotron call) and is discarded once this row is written — we persist
    a SHA-256 hash (for de-duplication/audit-trail matching without being
    able to recover the original text) and a short, truncated preview
    capped well below anything that could reconstruct the message.
    """
    __tablename__ = "intercepted_spam"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(128), ForeignKey("users.id"), nullable=False, index=True)

    source_app: Mapped[str] = mapped_column(String(50))         # com.whatsapp | sms | other
    sender_label: Mapped[str | None] = mapped_column(String(120), nullable=True)  # notification title, not full contact PII

    message_hash: Mapped[str] = mapped_column(String(64), index=True)   # SHA-256 hex digest, not reversible
    message_preview: Mapped[str] = mapped_column(String(60), default="")  # first ~60 chars only, for human triage

    local_rule_matched: Mapped[bool] = mapped_column(Boolean, default=False)
    matched_keywords: Mapped[list] = mapped_column(JSON, default=list)

    # --- Nemotron scam evaluation ---
    threat_score: Mapped[float] = mapped_column(Float, default=0.0)  # 0-100
    threat_level: Mapped[RiskLevel] = mapped_column(Enum(RiskLevel), default=RiskLevel.LOW)
    scam_category: Mapped[str | None] = mapped_column(String(100), nullable=True)  # e.g. "advance fee / plot booking"
    ai_explanation: Mapped[str] = mapped_column(Text, default="")

    user_alerted: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

    owner: Mapped["User"] = relationship(back_populates="spam_events")


# ----------------------------------------------------------------------
# Module 3 — Women's Safety Shield
# ----------------------------------------------------------------------

class SOSLog(Base):
    __tablename__ = "sos_logs"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(128), ForeignKey("users.id"), nullable=False, index=True)

    trigger_source: Mapped[str] = mapped_column(String(30))  # button | shake | manual
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    maps_link: Mapped[str] = mapped_column(String(255))

    status: Mapped[SOSStatus] = mapped_column(Enum(SOSStatus), default=SOSStatus.TRIGGERED)
    contacts_notified: Mapped[list] = mapped_column(JSON, default=list)  # phone numbers actually reached
    twilio_message_sids: Mapped[list] = mapped_column(JSON, default=list)
    failure_reason: Mapped[str | None] = mapped_column(String(500), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    owner: Mapped["User"] = relationship(back_populates="sos_logs")
