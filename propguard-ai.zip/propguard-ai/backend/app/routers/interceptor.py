"""
routers/interceptor.py
------------------------
Module 2: WhatsApp/SMS Spam Interceptor.

POST /api/v1/interceptor/scan
  Receives notification text captured on-device by the Android
  NotificationListenerService, re-checks it against a local keyword
  rule set, sends it to Nemotron for a deeper scam-severity read,
  persists the event, and returns whether the app should alert the user.
"""

from __future__ import annotations

import hashlib

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user, limiter
from app.database import get_db
from app.models import InterceptedSpam, RiskLevel
from app.schemas import InterceptorScanRequest, InterceptorScanResponse
from app.services.keyword_rules import match_local_keywords
from app.services.nemotron_client import nemotron_client

router = APIRouter(prefix="/interceptor", tags=["Module 2 - WhatsApp/SMS Interceptor"])

# Alert the user in-app whenever the model or the keyword rules think this
# is at least a MEDIUM threat.
ALERT_THRESHOLD_SCORE = 40.0

# Generous but bounded — this endpoint is called on every WhatsApp/SMS
# notification, so it needs headroom, while still blocking abuse/DDoS
# per PRD FR-2.3 / NFR (800ms budget) and the security checklist.
_RATE_LIMIT = "120/minute"


@router.post("/scan", response_model=InterceptorScanResponse, status_code=status.HTTP_201_CREATED)
@limiter.limit(_RATE_LIMIT)
async def scan_intercepted_message(
    request: Request,
    payload: InterceptorScanRequest,
    user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Privacy note: `payload.message_text` is used in-memory only (local
    keyword match + Nemotron call) and is never written to the database.
    Only a SHA-256 hash and a short truncated preview are persisted —
    see InterceptedSpam docstring in models.py.
    """
    user_id = user["uid"]

    matched_keywords = match_local_keywords(payload.message_text)
    local_rule_matched = len(matched_keywords) > 0

    ai_result = await nemotron_client.analyze_scam_message(payload.message_text)
    threat_score = float(ai_result.get("threat_score", 0))

    # Local keyword hits nudge the score up even if the model under-scores it,
    # so a clearly-matched phrase never silently slips through.
    if local_rule_matched:
        threat_score = max(threat_score, 45.0)

    threat_level = ai_result.get("threat_level", "LOW")
    should_alert = threat_score >= ALERT_THRESHOLD_SCORE or local_rule_matched

    message_hash = hashlib.sha256(payload.message_text.encode("utf-8")).hexdigest()
    message_preview = payload.message_text[:60]

    event = InterceptedSpam(
        user_id=user_id,
        source_app=payload.source_app,
        sender_label=payload.sender_label,
        message_hash=message_hash,
        message_preview=message_preview,
        local_rule_matched=local_rule_matched,
        matched_keywords=matched_keywords,
        threat_score=threat_score,
        threat_level=RiskLevel(threat_level) if threat_level in RiskLevel.__members__ else RiskLevel.LOW,
        scam_category=ai_result.get("scam_category"),
        ai_explanation=ai_result.get("explanation", ""),
        user_alerted=should_alert,
    )
    db.add(event)
    await db.commit()
    await db.refresh(event)
    # `payload.message_text` goes out of scope here — never persisted.

    return InterceptorScanResponse(
        id=event.id,
        threat_score=event.threat_score,
        threat_level=event.threat_level.value,
        scam_category=event.scam_category,
        ai_explanation=event.ai_explanation,
        should_alert_user=should_alert,
    )
