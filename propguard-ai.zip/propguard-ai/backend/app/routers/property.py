"""
routers/property.py
--------------------
Module 1: Real Estate Scam Detector.

POST /api/v1/property/audit
  Accepts a document image upload, runs ELA forensics + OCR, sends the
  combined signal to Nemotron for legal fraud reasoning, persists the
  full audit, and returns the structured result.
"""

from __future__ import annotations

import os
import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user, limiter
from app.config import get_settings
from app.database import get_db
from app.forensics.ela_detector import ELADetector
from app.models import PropertyAudit, RiskLevel
from app.schemas import PropertyAuditResponse
from app.services import ocr_service
from app.services.nemotron_client import nemotron_client

router = APIRouter(prefix="/property", tags=["Module 1 - Property Scam Detector"])
settings = get_settings()

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".pdf"}
_ela_detector = ELADetector()


@router.post("/audit", response_model=PropertyAuditResponse, status_code=status.HTTP_201_CREATED)
@limiter.limit("10/hour")  # per PRD security checklist: cap AI-credit-draining uploads per user
async def audit_property_document(
    request: Request,
    document_type: str = Form(default="other"),
    file: UploadFile = File(...),
    user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Full pipeline: upload -> ELA forensics -> OCR -> Nemotron legal reasoning -> persist.
    Requires a valid Firebase Bearer JWT; the audit is always attributed to
    the authenticated uid, never a client-supplied id.
    """
    user_id = user["uid"]

    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Unsupported file type '{ext}'. Allowed: {sorted(ALLOWED_EXTENSIONS)}",
        )

    contents = await file.read()
    max_bytes = settings.max_upload_mb * 1024 * 1024
    if len(contents) > max_bytes:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File exceeds {settings.max_upload_mb}MB limit.",
        )

    os.makedirs(settings.upload_dir, exist_ok=True)
    stored_filename = f"{uuid.uuid4()}{ext}"
    stored_path = os.path.join(settings.upload_dir, stored_filename)
    with open(stored_path, "wb") as f:
        f.write(contents)

    # --- PDF handling note ---
    # PDFs are converted to page images upstream (e.g. via pdf2image) before
    # reaching ELA/OCR, since both operate on raster images. For brevity this
    # blueprint assumes `file` is already an image; wire in pdf2image here
    # for production PDF support (see README "PDF Pipeline" section).
    if ext == ".pdf":
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="PDF-to-image conversion is stubbed in this blueprint — see README for pdf2image wiring.",
        )

    try:
        heatmap_dir = os.path.join(settings.upload_dir, "heatmaps")
        ela_result = _ela_detector.analyze(stored_path, heatmap_dir=heatmap_dir)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Image forensics failed: {exc}") from exc

    extracted_text = ocr_service.extract_text(stored_path)
    parsed_fields = ocr_service.parse_structured_fields(extracted_text)

    ai_result = await nemotron_client.analyze_property_fraud(
        extracted_text=extracted_text,
        ela_score=ela_result.ela_score,
        exif_anomalies=ela_result.exif_anomalies,
    )

    audit = PropertyAudit(
        user_id=user_id,
        original_filename=file.filename,
        stored_path=stored_path,
        document_type=document_type,
        ela_score=ela_result.ela_score,
        ela_heatmap_path=ela_result.heatmap_path,
        exif_anomalies=ela_result.exif_anomalies,
        extracted_text=extracted_text,
        owner_name=parsed_fields.get("owner_name"),
        survey_number=parsed_fields.get("survey_number"),
        deed_date=parsed_fields.get("deed_date"),
        stamp_duty_value=parsed_fields.get("stamp_duty_value"),
        fraud_risk_score=float(ai_result.get("fraud_risk_score", 0)),
        risk_level=RiskLevel(ai_result.get("risk_level", "LOW")),
        legal_red_flags=ai_result.get("legal_red_flags", []),
        ai_summary=ai_result.get("summary", ""),
        raw_model_response=ai_result.get("raw", {}),
    )
    db.add(audit)
    await db.commit()
    await db.refresh(audit)

    return audit
