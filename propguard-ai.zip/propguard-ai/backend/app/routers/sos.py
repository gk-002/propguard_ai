"""
routers/sos.py
----------------
Module 3: Women's Safety Shield.

POST /api/v1/sos/trigger
  Receives GPS coordinates from the Flutter app (button press or shake
  trigger), builds a Google Maps link, fans out SMS alerts to the user's
  emergency contacts via Twilio, and logs the full event.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user, limiter
from app.database import get_db
from app.models import SOSLog, SOSStatus, User
from app.schemas import SOSTriggerRequest, SOSTriggerResponse
from app.security.encryption import decrypt_contacts, decrypt_field, encrypt_field
from app.services.twilio_service import build_maps_link, send_sos_alerts

router = APIRouter(prefix="/sos", tags=["Module 3 - Women's Safety Shield"])


@router.post("/trigger", response_model=SOSTriggerResponse, status_code=status.HTTP_201_CREATED)
# Deliberately NOT aggressively rate-limited — an emergency pipeline must
# not be the place where a legitimate repeated-shake trigger gets throttled.
# A generous ceiling still guards against a compromised/looping client.
@limiter.limit("30/hour")
async def trigger_sos(
    request: Request,
    payload: SOSTriggerRequest,
    auth_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    uid = auth_user["uid"]
    user = (await db.execute(select(User).where(User.id == uid))).scalar_one_or_none()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No PropGuard profile found — set up emergency contacts via PUT /api/v1/users/me first.",
        )

    maps_link = build_maps_link(payload.latitude, payload.longitude)

    # Log the trigger immediately (before SMS dispatch) — an SOS event must
    # never be lost even if Twilio subsequently fails.
    sos_log = SOSLog(
        user_id=user.id,
        trigger_source=payload.trigger_source,
        latitude=payload.latitude,
        longitude=payload.longitude,
        maps_link=maps_link,
        status=SOSStatus.TRIGGERED,
    )
    db.add(sos_log)
    await db.commit()
    await db.refresh(sos_log)

    # Contacts are stored encrypted at rest — decrypt only in-memory,
    # immediately before handing off to Twilio.
    plaintext_contacts = decrypt_contacts(user.emergency_contacts)

    dispatch_result = await send_sos_alerts(
        contacts=plaintext_contacts,
        user_name=user.full_name,
        maps_link=maps_link,
        latitude=payload.latitude,
        longitude=payload.longitude,
    )

    # Phone numbers are PII — encrypt before persisting (PRD: "Encrypt
    # sensitive stored records ... phone numbers ... at rest using AES-256").
    sos_log.contacts_notified = [encrypt_field(p) for p in dispatch_result.notified]
    sos_log.twilio_message_sids = dispatch_result.message_sids
    if dispatch_result.notified:
        sos_log.status = SOSStatus.SMS_SENT
    else:
        sos_log.status = SOSStatus.SMS_FAILED
        sos_log.failure_reason = "; ".join(dispatch_result.errors) or "Unknown Twilio failure."

    await db.commit()
    await db.refresh(sos_log)

    return SOSTriggerResponse(
        id=sos_log.id,
        status=sos_log.status.value,
        maps_link=sos_log.maps_link,
        # Decrypt back to plaintext only for this immediate response to the
        # authenticated owner of the SOS event — never logged or cached.
        contacts_notified=[decrypt_field(p) for p in sos_log.contacts_notified],
        failure_reason=sos_log.failure_reason,
    )
