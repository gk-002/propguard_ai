"""
routers/users.py
------------------
Post-authentication onboarding: an authenticated Firebase user creates/
updates their PropGuard profile row (full name + up to 5 emergency
contacts, per FR-3.3). This is what SOSLog dispatch reads from at
trigger time.

All endpoints require a valid Firebase JWT — see app/auth.py.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.database import get_db
from app.models import User
from app.schemas import UserProfileResponse, UserProfileUpsertRequest
from app.security.encryption import decrypt_contacts, encrypt_contacts

router = APIRouter(prefix="/users", tags=["User Profile"])


@router.put("/me", response_model=UserProfileResponse)
async def upsert_my_profile(
    payload: UserProfileUpsertRequest,
    user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Creates the profile row on first call, updates it on subsequent calls."""
    uid = user["uid"]
    existing = (await db.execute(select(User).where(User.id == uid))).scalar_one_or_none()

    encrypted_contacts = encrypt_contacts([c.model_dump() for c in payload.emergency_contacts])

    if existing is None:
        existing = User(
            id=uid,
            full_name=payload.full_name,
            email=user.get("email"),
            emergency_contacts=encrypted_contacts,
        )
        db.add(existing)
    else:
        existing.full_name = payload.full_name
        existing.emergency_contacts = encrypted_contacts

    await db.commit()
    await db.refresh(existing)

    return UserProfileResponse(
        id=existing.id,
        full_name=existing.full_name,
        email=existing.email,
        emergency_contacts=decrypt_contacts(existing.emergency_contacts),
        created_at=existing.created_at,
    )


@router.get("/me", response_model=UserProfileResponse)
async def get_my_profile(
    user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    uid = user["uid"]
    existing = (await db.execute(select(User).where(User.id == uid))).scalar_one_or_none()
    if existing is None:
        # First login, no profile yet — return an empty shell rather than
        # a 404, so the Flutter app can distinguish "not onboarded" from
        # "server error" and show the setup screen.
        return UserProfileResponse(
            id=uid, full_name="", email=user.get("email"), emergency_contacts=[], created_at=None,
        )

    return UserProfileResponse(
        id=existing.id,
        full_name=existing.full_name,
        email=existing.email,
        emergency_contacts=decrypt_contacts(existing.emergency_contacts),
        created_at=existing.created_at,
    )
