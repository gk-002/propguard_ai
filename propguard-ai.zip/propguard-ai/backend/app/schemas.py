"""
schemas.py
----------
Pydantic v2 request/response models — the API's public contract.
Keeping these separate from ORM models prevents leaking internal DB fields.
"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


# ----------------------------------------------------------------------
# User profile (post-authentication onboarding)
# ----------------------------------------------------------------------

class EmergencyContact(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    phone: str = Field(min_length=8, max_length=20, examples=["+919812345678"])


class UserProfileUpsertRequest(BaseModel):
    full_name: str = Field(min_length=1, max_length=120)
    emergency_contacts: list[EmergencyContact] = Field(default_factory=list, max_length=5)


class UserProfileResponse(BaseModel):
    id: str
    full_name: str
    email: str | None
    emergency_contacts: list[EmergencyContact]
    created_at: datetime | None = None


# ----------------------------------------------------------------------
# Module 1 — Property Audit
# ----------------------------------------------------------------------

class PropertyAuditResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    original_filename: str
    document_type: str
    ela_score: float
    ela_heatmap_path: str | None
    exif_anomalies: list
    extracted_text: str
    owner_name: str | None
    survey_number: str | None
    deed_date: str | None
    stamp_duty_value: str | None
    fraud_risk_score: float
    risk_level: str
    legal_red_flags: list
    ai_summary: str
    created_at: datetime


# ----------------------------------------------------------------------
# Module 2 — Interceptor
# ----------------------------------------------------------------------

class InterceptorScanRequest(BaseModel):
    # NOTE: no user_id field here on purpose — the authenticated uid from
    # the verified Firebase JWT (see app/auth.py) is the only source of
    # identity the backend trusts. A client-supplied user_id would let one
    # user attribute events to another.
    source_app: str = Field(default="com.whatsapp", examples=["com.whatsapp", "sms"])
    sender_label: str | None = None
    message_text: str = Field(min_length=1, max_length=4000)


class InterceptorScanResponse(BaseModel):
    id: str
    threat_score: float
    threat_level: str
    scam_category: str | None
    ai_explanation: str
    should_alert_user: bool


# ----------------------------------------------------------------------
# Module 3 — SOS
# ----------------------------------------------------------------------

class SOSTriggerRequest(BaseModel):
    # user_id intentionally omitted — resolved from the verified JWT.
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    trigger_source: str = Field(default="button", examples=["button", "shake", "manual"])


class SOSTriggerResponse(BaseModel):
    id: str
    status: str
    maps_link: str
    contacts_notified: list[str]
    failure_reason: str | None = None
