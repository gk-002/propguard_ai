"""
keyword_rules.py
------------------
Lightweight keyword rule set mirrored on both the Android on-device filter
(Kotlin) and here on the backend, so that even if the app's local filter
misses something, the backend re-checks before/alongside the Nemotron call.
This is cheap, offline, and instant — Nemotron is the deeper second opinion.
"""

import re

SCAM_KEYWORDS = [
    "guaranteed return",
    "guaranteed returns",
    "urgent plot booking",
    "transfer advance",
    "advance payment required",
    "limited time offer",
    "book now pay later",
    "no documentation required",
    "double your investment",
    "risk free investment",
    "token amount",
    "pay to block",
    "confirm booking with token",
]

_PATTERN = re.compile("|".join(re.escape(k) for k in SCAM_KEYWORDS), re.IGNORECASE)


def match_local_keywords(text: str) -> list[str]:
    """Returns the list of scam keywords found in the given text (case-insensitive)."""
    return sorted({m.group(0).lower() for m in _PATTERN.finditer(text)})
