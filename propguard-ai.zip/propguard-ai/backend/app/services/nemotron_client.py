"""
nemotron_client.py
-------------------
Thin async wrapper around NVIDIA's NIM API (OpenAI-compatible endpoint),
used for two distinct reasoning tasks:

  1. Legal fraud analysis of property documents (Module 1)
  2. Scam severity scoring of intercepted WhatsApp/SMS text (Module 2)

Both prompts force strict JSON output so the FastAPI layer can parse
results deterministically without a second "explain your answer" round-trip.
"""

from __future__ import annotations

import json
import logging

from openai import AsyncOpenAI, APIError, APITimeoutError

from app.config import get_settings

logger = logging.getLogger("propguard.nemotron")
settings = get_settings()

_client = AsyncOpenAI(
    base_url=settings.nvidia_base_url,
    api_key=settings.nvidia_api_key,
    timeout=settings.nvidia_request_timeout_seconds,
)


PROPERTY_FRAUD_SYSTEM_PROMPT = """\
You are a real-estate legal fraud analyst for an Indian civic-safety platform.
You will be given OCR-extracted text from a property document (title deed, NOC,
or sale agreement) plus an image-forensics Error Level Analysis (ELA) score
(0-100, higher = more likely digitally altered) and any EXIF anomalies found.

Analyze the document for signs of fraud: altered survey numbers, inconsistent
dates, mismatched owner names, suspicious stamp duty values, forged-looking
clauses, or missing mandatory legal fields for Indian property transactions.

Respond ONLY with valid JSON (no markdown fences, no prose) in exactly this shape:
{
  "fraud_risk_score": <integer 0-100>,
  "risk_level": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
  "legal_red_flags": ["short red flag 1", "short red flag 2", ...],
  "summary": "2-3 sentence plain-language explanation for a non-lawyer user"
}
"""

SCAM_MESSAGE_SYSTEM_PROMPT = """\
You are a scam-detection analyst for a civic-safety app that intercepts
WhatsApp/SMS notifications about real-estate deals (plot bookings, "guaranteed
returns", advance-payment demands, urgent limited-time offers, etc.).

Given a message's text, evaluate how likely it is to be a scam and how
severe the threat is.

Respond ONLY with valid JSON (no markdown fences, no prose) in exactly this shape:
{
  "threat_score": <integer 0-100>,
  "threat_level": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
  "scam_category": "short category label or null",
  "explanation": "1-2 sentence plain-language explanation for the end user"
}
"""


class NemotronClient:
    """Async wrapper with automatic fallback to a secondary model on failure."""

    def __init__(self, client: AsyncOpenAI = _client):
        self._client = client

    async def _chat_json(self, system_prompt: str, user_content: str) -> dict:
        """
        Calls Nemotron with a low temperature (deterministic-ish structured output)
        and falls back to the secondary model once if the primary errors out.
        """
        models_to_try = [settings.nvidia_model_primary, settings.nvidia_model_fallback]
        last_error: Exception | None = None

        for model in models_to_try:
            try:
                response = await self._client.chat.completions.create(
                    model=model,
                    temperature=0.1,
                    max_tokens=800,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_content},
                    ],
                )
                raw = response.choices[0].message.content or "{}"
                return self._safe_parse_json(raw)

            except (APIError, APITimeoutError) as exc:
                logger.warning("Nemotron call failed on model=%s: %s", model, exc)
                last_error = exc
                continue

        # Both primary and fallback failed — surface a safe default rather
        # than crash the whole audit/scan request.
        logger.error("All Nemotron models failed: %s", last_error)
        return {"_error": str(last_error)}

    @staticmethod
    def _safe_parse_json(raw: str) -> dict:
        """Strip accidental markdown fences and parse JSON defensively."""
        cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            logger.error("Failed to parse Nemotron JSON response: %r", raw)
            return {"_error": "unparseable_model_response", "_raw": raw}

    # ------------------------------------------------------------------
    # Module 1: Property fraud analysis
    # ------------------------------------------------------------------

    async def analyze_property_fraud(
        self, extracted_text: str, ela_score: float, exif_anomalies: list[str]
    ) -> dict:
        user_content = (
            f"OCR EXTRACTED TEXT:\n{extracted_text[:6000]}\n\n"
            f"IMAGE FORENSICS ELA SCORE: {ela_score}/100\n"
            f"EXIF ANOMALIES: {exif_anomalies or 'None detected'}\n\n"
            "Provide your fraud analysis as specified."
        )
        result = await self._chat_json(PROPERTY_FRAUD_SYSTEM_PROMPT, user_content)
        return self._normalize_property_result(result, ela_score)

    def _normalize_property_result(self, result: dict, ela_score: float) -> dict:
        if "_error" in result:
            # Fail safe: fall back to a conservative score derived purely from
            # the ELA signal so the pipeline still returns something useful.
            fallback_score = min(ela_score * 0.8, 100.0)
            return {
                "fraud_risk_score": round(fallback_score, 1),
                "risk_level": self._level_from_score(fallback_score),
                "legal_red_flags": ["AI reasoning service unavailable — score based on image forensics only."],
                "summary": "Automated legal analysis was unavailable; this score reflects image forensics only.",
                "raw": result,
            }
        result.setdefault("fraud_risk_score", 0)
        result.setdefault("risk_level", self._level_from_score(result["fraud_risk_score"]))
        result.setdefault("legal_red_flags", [])
        result.setdefault("summary", "")
        result["raw"] = result.copy()
        return result

    # ------------------------------------------------------------------
    # Module 2: Scam message scoring
    # ------------------------------------------------------------------

    async def analyze_scam_message(self, message_text: str) -> dict:
        user_content = f"MESSAGE TEXT:\n{message_text[:2000]}"
        result = await self._chat_json(SCAM_MESSAGE_SYSTEM_PROMPT, user_content)
        return self._normalize_scam_result(result)

    def _normalize_scam_result(self, result: dict) -> dict:
        if "_error" in result:
            return {
                "threat_score": 50,
                "threat_level": "MEDIUM",
                "scam_category": None,
                "explanation": "AI reasoning service unavailable — flagged for manual review as a precaution.",
                "raw": result,
            }
        result.setdefault("threat_score", 0)
        result.setdefault("threat_level", self._level_from_score(result["threat_score"]))
        result.setdefault("scam_category", None)
        result.setdefault("explanation", "")
        result["raw"] = result.copy()
        return result

    @staticmethod
    def _level_from_score(score: float) -> str:
        if score >= 80:
            return "CRITICAL"
        if score >= 55:
            return "HIGH"
        if score >= 25:
            return "MEDIUM"
        return "LOW"


nemotron_client = NemotronClient()
