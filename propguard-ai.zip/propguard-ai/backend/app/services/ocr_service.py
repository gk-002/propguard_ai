"""
ocr_service.py
---------------
Extracts raw text via Tesseract OCR, then parses structured fields
(Owner Name, Survey Number, Deed Date, Stamp Duty Value) using regex.

Regex parsing here is intentionally a first-pass heuristic — Nemotron
gets the full raw text too, so it can catch fields the regex misses
or is fooled by.
"""

from __future__ import annotations

import re

import pytesseract
from PIL import Image

from app.config import get_settings

settings = get_settings()
pytesseract.pytesseract.tesseract_cmd = settings.tesseract_cmd


FIELD_PATTERNS = {
    "owner_name": re.compile(r"(?:owner|name of owner|purchaser|vendee)\s*[:\-]\s*([A-Za-z .]{3,60})", re.IGNORECASE),
    "survey_number": re.compile(r"(?:survey\s*(?:no\.?|number)|s\.?no\.?)\s*[:\-]?\s*([A-Za-z0-9/\-]{1,20})", re.IGNORECASE),
    "deed_date": re.compile(r"(?:dated|date of execution|executed on)\s*[:\-]?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})", re.IGNORECASE),
    "stamp_duty_value": re.compile(r"(?:stamp duty|market value|consideration)\s*[:\-]?\s*(?:rs\.?|inr)?\s*([\d,]+(?:\.\d+)?)", re.IGNORECASE),
}


def extract_text(image_path: str) -> str:
    """Run Tesseract OCR over the document image and return raw text."""
    try:
        img = Image.open(image_path)
        # Basic preprocessing: convert to grayscale to improve OCR accuracy on scans.
        img = img.convert("L")
        return pytesseract.image_to_string(img)
    except Exception as exc:  # noqa: BLE001
        # Return empty text rather than crash the audit pipeline; Nemotron
        # and the ELA score can still produce a partial result.
        return f"[OCR_ERROR: {exc}]"


def parse_structured_fields(raw_text: str) -> dict[str, str | None]:
    """Best-effort regex extraction of key legal document fields."""
    fields: dict[str, str | None] = {}
    for field_name, pattern in FIELD_PATTERNS.items():
        match = pattern.search(raw_text)
        fields[field_name] = match.group(1).strip() if match else None
    return fields
