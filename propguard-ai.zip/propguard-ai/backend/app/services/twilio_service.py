"""
twilio_service.py
------------------
Wraps Twilio's REST API for emergency SOS SMS dispatch (Module 3).

Uses the synchronous Twilio SDK inside a thread pool executor so it doesn't
block the FastAPI event loop (Twilio's official SDK is sync-only).
"""

from __future__ import annotations

import asyncio
import logging

from twilio.base.exceptions import TwilioRestException
from twilio.rest import Client

from app.config import get_settings

logger = logging.getLogger("propguard.twilio")
settings = get_settings()

_twilio_client = Client(settings.twilio_account_sid, settings.twilio_auth_token)


class SOSDispatchResult:
    def __init__(self):
        self.notified: list[str] = []
        self.message_sids: list[str] = []
        self.errors: list[str] = []

    @property
    def all_failed(self) -> bool:
        return len(self.notified) == 0 and len(self.errors) > 0


async def send_sos_alerts(
    contacts: list[dict], user_name: str, maps_link: str, latitude: float, longitude: float
) -> SOSDispatchResult:
    """
    Sends an SOS SMS to every emergency contact in parallel.
    `contacts` is a list of {"name": str, "phone": "+91..."} dicts pulled
    from the user's profile.
    """
    result = SOSDispatchResult()

    if not contacts:
        result.errors.append("No emergency contacts configured for this user.")
        return result

    body = (
        f"🚨 SOS ALERT from {user_name} (PropGuard AI Safety Shield)\n"
        f"They may need urgent help. Last known location:\n{maps_link}\n"
        f"Coordinates: {latitude:.6f}, {longitude:.6f}\n"
        f"Please try to contact them immediately."
    )

    tasks = [_send_single_sms(contact, body, result) for contact in contacts]
    await asyncio.gather(*tasks)
    return result


async def _send_single_sms(contact: dict, body: str, result: SOSDispatchResult) -> None:
    phone = contact.get("phone")
    if not phone:
        result.errors.append(f"Contact '{contact.get('name', 'unknown')}' missing phone number.")
        return

    loop = asyncio.get_running_loop()
    try:
        message = await loop.run_in_executor(
            None,
            lambda: _twilio_client.messages.create(
                body=body,
                from_=settings.twilio_from_number,
                to=phone,
            ),
        )
        result.notified.append(phone)
        result.message_sids.append(message.sid)
    except TwilioRestException as exc:
        logger.error("Twilio SMS failed for %s: %s", phone, exc)
        result.errors.append(f"{phone}: {exc.msg}")
    except Exception as exc:  # noqa: BLE001 — never let one bad contact abort the whole SOS fan-out
        logger.error("Unexpected error sending SOS to %s: %s", phone, exc)
        result.errors.append(f"{phone}: {exc}")


def build_maps_link(latitude: float, longitude: float) -> str:
    """Formats a Google Maps deep link from raw GPS coordinates."""
    return f"https://www.google.com/maps?q={latitude},{longitude}"
