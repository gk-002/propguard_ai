# ⚠️ Superseded by `mobile/flutter_app/android`

This folder was the original standalone reference copy of the native Kotlin
notification-listener module. It is **kept here for reference only**.

The real, buildable copy — wired into an actual Flutter Android Gradle
project with Firebase Auth, ProGuard rules, and the `notification_access`
platform channel — lives at:

```
mobile/flutter_app/android/app/src/main/kotlin/com/propguard/app/interceptor/
```

Build the APK from `mobile/flutter_app/`, not from this folder. See the
root `README.md` → "Building the Android APK" for instructions.
