plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.propguard.app"
    compileSdk = 34
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "com.propguard.app"
        minSdk = 24            // NotificationListenerService requires API 19+; 24 keeps modern coroutine/Firebase support
        targetSdk = 34
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        create("release") {
            // Populated from android/key.properties at build time — see README
            // "Signing the Release APK". Never commit key.properties or the
            // .jks keystore itself.
            val keystorePropertiesFile = rootProject.file("key.properties")
            if (keystorePropertiesFile.exists()) {
                val keystoreProperties = java.util.Properties()
                keystoreProperties.load(keystorePropertiesFile.inputStream())
                storeFile = file(keystoreProperties["storeFile"] as String)
                storePassword = keystoreProperties["storePassword"] as String
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = keystoreProperties["keyPassword"] as String
            }
        }
    }

    buildTypes {
        release {
            // Falls back to the debug signature if key.properties isn't
            // present (e.g. CI builds without secrets configured yet) so
            // `flutter build apk` still succeeds for smoke-testing.
            signingConfig = if (rootProject.file("key.properties").exists())
                signingConfigs.getByName("release")
            else
                signingConfigs.getByName("debug")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    // Kotlin coroutines for async notification dispatch (WhatsAppSpamListener)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Lightweight HTTP client used by the native listener to call the backend directly
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.core:core-ktx:1.13.1")

    // Firebase (BoM manages consistent versions across firebase-* libs)
    implementation(platform("com.google.firebase:firebase-bom:33.3.0"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")

    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.2")
}
