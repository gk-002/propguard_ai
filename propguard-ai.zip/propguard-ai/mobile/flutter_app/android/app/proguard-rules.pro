# PropGuard AI — release ProGuard/R8 rules

# Firebase Auth reflection-based model classes
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

# OkHttp / okio (used by WhatsAppSpamListener for direct backend calls)
-dontwarn okhttp3.**
-dontwarn okio.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# org.json is part of the Android SDK, safe to keep as-is (no rule needed)

# Kotlin coroutines
-dontwarn kotlinx.coroutines.**
