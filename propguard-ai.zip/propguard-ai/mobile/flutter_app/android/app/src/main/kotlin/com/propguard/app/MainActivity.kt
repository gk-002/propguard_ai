package com.propguard.app

import android.content.Intent
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * MainActivity
 * -------------
 * Hosts the Flutter UI and exposes one platform channel,
 * "propguard/notification_access", used by
 * lib/screens/whatsapp_shield_screen.dart to check and request Android's
 * Notification Access permission for WhatsAppSpamListener (Module 2).
 *
 * This permission cannot be requested via the normal runtime permission
 * dialog — Android requires the user to grant it manually from Settings.
 */
class MainActivity : FlutterActivity() {

    private val channelName = "propguard/notification_access"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "isNotificationAccessEnabled" -> {
                    result.success(isNotificationAccessEnabled())
                }
                "openNotificationAccessSettings" -> {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun isNotificationAccessEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?: return false
        return enabledListeners.contains(packageName)
    }
}
