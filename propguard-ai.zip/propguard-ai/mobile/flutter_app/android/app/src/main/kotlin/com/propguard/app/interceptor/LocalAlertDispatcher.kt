package com.propguard.app.interceptor

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONObject

/**
 * LocalAlertDispatcher
 * ----------------------
 * Posts an in-app / system-tray warning notification when a scam is
 * detected — either instantly from the local keyword filter, or after
 * the backend/Nemotron verdict comes back.
 */
object LocalAlertDispatcher {

    private const val CHANNEL_ID = "propguard_scam_alerts"
    private const val CHANNEL_NAME = "PropGuard Scam Alerts"
    private const val NOTIFICATION_ID_BASE = 9000

    fun showImmediateWarning(context: Context, sender: String, matchedKeywords: List<String>) {
        ensureChannel(context)
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("⚠️ Possible scam message from $sender")
            .setContentText("Flagged phrases: ${matchedKeywords.joinToString(", ")}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        getManager(context).notify(NOTIFICATION_ID_BASE + sender.hashCode() % 1000, builder.build())
    }

    fun showBackendVerdict(context: Context, result: JSONObject) {
        ensureChannel(context)
        val threatLevel = result.optString("threat_level", "MEDIUM")
        val explanation = result.optString("ai_explanation", "This message may be a scam.")

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("🚨 PropGuard AI: $threatLevel risk message detected")
            .setContentText(explanation)
            .setStyle(NotificationCompat.BigTextStyle().bigText(explanation))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        getManager(context).notify(NOTIFICATION_ID_BASE + threatLevel.hashCode() % 1000, builder.build())
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Warnings about potential real-estate scam messages."
            }
            getManager(context).createNotificationChannel(channel)
        }
    }

    private fun getManager(context: Context): NotificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
}
