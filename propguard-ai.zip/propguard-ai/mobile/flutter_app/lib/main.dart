// main.dart
// ---------
// PropGuard AI — app entrypoint.
// Boots Firebase, then gates the UI on auth state:
//   not signed in       -> LoginScreen (Phone OTP / Email+Password)
//   signed in, no profile -> ProfileSetupScreen (name + emergency contacts)
//   signed in, has profile -> RootShell (the 3-tab module shell)

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'screens/property_auditor_screen.dart';
import 'screens/whatsapp_shield_screen.dart';
import 'screens/sos_screen.dart';
import 'screens/login_screen.dart';
import 'screens/profile_setup_screen.dart';
import 'services/auth_service.dart';
import 'services/api_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // On Android, configuration is auto-loaded from
  // android/app/google-services.json (see README "Firebase Setup") —
  // no explicit FirebaseOptions needed for an Android-only build.
  await Firebase.initializeApp();
  runApp(const PropGuardApp());
}

class PropGuardApp extends StatelessWidget {
  const PropGuardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PropGuard AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B4332), // deep civic-safety green
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
        ),
      ),
      home: const RootGate(),
    );
  }
}

/// RootGate listens to Firebase auth state and routes to the right screen.
class RootGate extends StatelessWidget {
  const RootGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: AuthService.instance.authStateChanges,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final signedIn = snapshot.data != null;
        if (!signedIn) {
          return const LoginScreen();
        }
        return const _ProfileGate();
      },
    );
  }
}

/// After sign-in, checks whether the user has completed emergency-contact
/// onboarding (required for the SOS module to function) before entering
/// the main app shell.
class _ProfileGate extends StatefulWidget {
  const _ProfileGate();

  @override
  State<_ProfileGate> createState() => _ProfileGateState();
}

class _ProfileGateState extends State<_ProfileGate> {
  bool _loading = true;
  bool _hasProfile = false;

  @override
  void initState() {
    super.initState();
    _checkProfile();
  }

  Future<void> _checkProfile() async {
    try {
      final profile = await ApiService.getProfile();
      final contacts = (profile['emergency_contacts'] as List?) ?? [];
      setState(() {
        _hasProfile = (profile['full_name'] as String? ?? '').isNotEmpty && contacts.isNotEmpty;
        _loading = false;
      });
    } catch (_) {
      // Backend unreachable or profile not found — send to setup either way.
      setState(() {
        _hasProfile = false;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (!_hasProfile) {
      return ProfileSetupScreen(onComplete: () => setState(() => _hasProfile = true));
    }
    return const RootShell();
  }
}

/// RootShell hosts the three module tabs behind a single bottom nav bar.
class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _selectedIndex = 0;

  static const List<Widget> _screens = [
    PropertyAuditorScreen(),
    WhatsAppShieldScreen(),
    SosScreen(),
  ];

  static const List<_TabSpec> _tabs = [
    _TabSpec(icon: Icons.gavel_rounded, label: 'Property Auditor'),
    _TabSpec(icon: Icons.shield_moon_rounded, label: 'WhatsApp Shield'),
    _TabSpec(icon: Icons.sos_rounded, label: 'Emergency SOS'),
  ];

  void _onTabTapped(int index) {
    setState(() => _selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_tabs[_selectedIndex].label),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_rounded),
            tooltip: 'Sign out',
            onPressed: () => AuthService.instance.signOut(),
          ),
        ],
      ),
      body: SafeArea(
        child: IndexedStack(
          index: _selectedIndex,
          children: _screens,
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: _onTabTapped,
        destinations: _tabs
            .map((tab) => NavigationDestination(
                  icon: Icon(tab.icon),
                  label: tab.label,
                ))
            .toList(),
      ),
    );
  }
}

class _TabSpec {
  final IconData icon;
  final String label;
  const _TabSpec({required this.icon, required this.label});
}

