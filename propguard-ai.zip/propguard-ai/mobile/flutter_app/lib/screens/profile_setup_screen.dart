// profile_setup_screen.dart
// ----------------------------
// Post-login onboarding: collects full name + up to 5 emergency contacts
// (FR-3.3 caps at 5) and saves them via PUT /api/v1/users/me. The SOS
// module reads these contacts server-side at trigger time.

import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ProfileSetupScreen extends StatefulWidget {
  final VoidCallback onComplete;
  const ProfileSetupScreen({super.key, required this.onComplete});

  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ContactField {
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final _nameController = TextEditingController();
  final List<_ContactField> _contacts = [_ContactField()];
  bool _isSaving = false;
  String? _error;

  static const int _maxContacts = 5;

  void _addContact() {
    if (_contacts.length >= _maxContacts) return;
    setState(() => _contacts.add(_ContactField()));
  }

  void _removeContact(int index) {
    setState(() => _contacts.removeAt(index));
  }

  Future<void> _save() async {
    if (_nameController.text.trim().isEmpty) {
      setState(() => _error = 'Please enter your name.');
      return;
    }
    final contacts = _contacts
        .where((c) => c.nameController.text.trim().isNotEmpty && c.phoneController.text.trim().isNotEmpty)
        .map((c) => {'name': c.nameController.text.trim(), 'phone': c.phoneController.text.trim()})
        .toList();

    if (contacts.isEmpty) {
      setState(() => _error = 'Add at least one emergency contact for SOS to work.');
      return;
    }

    setState(() {
      _isSaving = true;
      _error = null;
    });

    try {
      await ApiService.upsertProfile(
        fullName: _nameController.text.trim(),
        emergencyContacts: contacts,
      );
      widget.onComplete();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Could not save profile: $e');
    } finally {
      setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Set Up Your Safety Profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'PropGuard needs your name and at least one emergency contact '
            'to send SOS alerts when you need help.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _nameController,
            decoration: const InputDecoration(labelText: 'Your full name', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 24),
          Text('Emergency Contacts (up to $_maxContacts)', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ..._contacts.asMap().entries.map((entry) {
            final i = entry.key;
            final c = entry.value;
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: TextField(
                      controller: c.nameController,
                      decoration: const InputDecoration(labelText: 'Name', border: OutlineInputBorder(), isDense: true),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 3,
                    child: TextField(
                      controller: c.phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                        labelText: '+91XXXXXXXXXX',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ),
                  if (_contacts.length > 1)
                    IconButton(
                      icon: const Icon(Icons.remove_circle_outline_rounded, color: Colors.red),
                      onPressed: () => _removeContact(i),
                    ),
                ],
              ),
            );
          }),
          if (_contacts.length < _maxContacts)
            OutlinedButton.icon(
              onPressed: _addContact,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Add another contact'),
            ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 24),
          FilledButton(
            onPressed: _isSaving ? null : _save,
            child: _isSaving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Save & Continue'),
          ),
        ],
      ),
    );
  }
}
