// property_auditor_screen.dart
// -------------------------------
// Module 1 UI: upload a property document (title deed / NOC / sale
// agreement), trigger the backend forensics+OCR+Nemotron pipeline, and
// display the fraud risk score, red flags, and ELA heatmap.

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/api_service.dart';

class PropertyAuditorScreen extends StatefulWidget {
  const PropertyAuditorScreen({super.key});

  @override
  State<PropertyAuditorScreen> createState() => _PropertyAuditorScreenState();
}

class _PropertyAuditorScreenState extends State<PropertyAuditorScreen> {
  File? _selectedFile;
  String _documentType = 'title_deed';
  bool _isLoading = false;
  Map<String, dynamic>? _result;
  String? _error;

  final List<String> _documentTypes = const [
    'title_deed',
    'noc',
    'sale_agreement',
    'other',
  ];

  Future<void> _pickDocument() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (picked != null) {
      setState(() {
        _selectedFile = File(picked.path);
        _result = null;
        _error = null;
      });
    }
  }

  Future<void> _runAudit() async {
    if (_selectedFile == null) return;
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final result = await ApiService.auditProperty(
        file: _selectedFile!,
        documentType: _documentType,
      );
      setState(() => _result = result);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Unexpected error: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Color _riskColor(String? level) {
    switch (level) {
      case 'CRITICAL':
        return Colors.red.shade700;
      case 'HIGH':
        return Colors.deepOrange;
      case 'MEDIUM':
        return Colors.amber.shade800;
      default:
        return Colors.green.shade700;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Property Scam Auditor')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('1. Select document type', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    initialValue: _documentType,
                    items: _documentTypes
                        .map((t) => DropdownMenuItem(value: t, child: Text(t.replaceAll('_', ' ').toUpperCase())))
                        .toList(),
                    onChanged: (v) => setState(() => _documentType = v ?? _documentType),
                  ),
                  const SizedBox(height: 16),
                  Text('2. Upload the document', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _pickDocument,
                    icon: const Icon(Icons.upload_file_rounded),
                    label: Text(_selectedFile == null ? 'Choose file' : 'File selected ✓'),
                  ),
                  if (_selectedFile != null) ...[
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(_selectedFile!, height: 180, fit: BoxFit.cover),
                    ),
                  ],
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: (_selectedFile == null || _isLoading) ? null : _runAudit,
                    icon: _isLoading
                        ? const SizedBox(
                            width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Icon(Icons.search_rounded),
                    label: Text(_isLoading ? 'Analyzing…' : 'Run Fraud Audit'),
                  ),
                ],
              ),
            ),
          ),
          if (_error != null) ...[
            const SizedBox(height: 16),
            Card(
              color: Colors.red.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(_error!, style: TextStyle(color: Colors.red.shade900)),
              ),
            ),
          ],
          if (_result != null) ...[
            const SizedBox(height: 16),
            _buildResultCard(context),
          ],
        ],
      ),
    );
  }

  Widget _buildResultCard(BuildContext context) {
    final r = _result!;
    final riskLevel = r['risk_level'] as String?;
    final fraudScore = (r['fraud_risk_score'] as num?)?.toDouble() ?? 0.0;
    final elaScore = (r['ela_score'] as num?)?.toDouble() ?? 0.0;
    final redFlags = (r['legal_red_flags'] as List?)?.cast<String>() ?? [];

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Fraud Risk Score', style: Theme.of(context).textTheme.titleMedium),
                Chip(
                  label: Text(riskLevel ?? 'LOW', style: const TextStyle(color: Colors.white)),
                  backgroundColor: _riskColor(riskLevel),
                ),
              ],
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: (fraudScore / 100).clamp(0.0, 1.0),
              minHeight: 10,
              borderRadius: BorderRadius.circular(6),
              color: _riskColor(riskLevel),
            ),
            const SizedBox(height: 4),
            Text('${fraudScore.toStringAsFixed(0)} / 100'),
            const SizedBox(height: 16),
            Text('Image Forensics (ELA) Score: ${elaScore.toStringAsFixed(1)} / 100',
                style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 16),
            Text('Legal Red Flags', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (redFlags.isEmpty)
              const Text('No red flags detected.')
            else
              ...redFlags.map((flag) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.warning_amber_rounded, size: 18, color: Colors.deepOrange),
                        const SizedBox(width: 8),
                        Expanded(child: Text(flag)),
                      ],
                    ),
                  )),
            const SizedBox(height: 12),
            Text('AI Summary', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(r['ai_summary'] as String? ?? ''),
          ],
        ),
      ),
    );
  }
}
