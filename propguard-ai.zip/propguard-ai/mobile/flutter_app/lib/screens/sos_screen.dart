// sos_screen.dart
// -----------------
// Module 3 UI: big SOS button + status of the background shake-trigger
// listener. Captures GPS via geolocator and calls POST /api/v1/sos/trigger.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../services/api_service.dart';

class SosScreen extends StatefulWidget {
  const SosScreen({super.key});

  @override
  State<SosScreen> createState() => _SosScreenState();
}

class _SosScreenState extends State<SosScreen> {
  bool _isSending = false;
  String? _statusMessage;
  bool _lastSendSucceeded = false;

  // Identity comes from the Firebase ID token attached by ApiService —
  // no user id needs to be threaded through manually.

  Future<Position> _getCurrentLocation() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('Location services are disabled. Please enable GPS.');
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Location permission denied.');
      }
    }
    if (permission == LocationPermission.deniedForever) {
      throw Exception('Location permission permanently denied — enable it in Settings.');
    }

    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
    );
  }

  Future<void> _triggerSos({required String source}) async {
    setState(() {
      _isSending = true;
      _statusMessage = null;
    });

    try {
      final position = await _getCurrentLocation();
      final result = await ApiService.triggerSos(
        latitude: position.latitude,
        longitude: position.longitude,
        triggerSource: source,
      );

      final status = result['status'] as String? ?? 'UNKNOWN';
      final contactsNotified = (result['contacts_notified'] as List?)?.length ?? 0;

      setState(() {
        _lastSendSucceeded = status == 'SMS_SENT';
        _statusMessage = _lastSendSucceeded
            ? 'SOS sent! $contactsNotified emergency contact(s) notified.'
            : 'SOS logged, but SMS dispatch failed: ${result['failure_reason'] ?? 'unknown error'}';
      });
    } on ApiException catch (e) {
      setState(() {
        _lastSendSucceeded = false;
        _statusMessage = 'Server error: ${e.message}';
      });
    } catch (e) {
      setState(() {
        _lastSendSucceeded = false;
        _statusMessage = 'Could not send SOS: $e';
      });
    } finally {
      setState(() => _isSending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Emergency SOS')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.shield_rounded, size: 64, color: Color(0xFF1B4332)),
            const SizedBox(height: 8),
            Text(
              'Press and hold in an emergency.\nYour location will be shared with your '
              'emergency contacts instantly via SMS.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 40),
            GestureDetector(
              onLongPress: _isSending ? null : () => _triggerSos(source: 'button'),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 180,
                height: 180,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _isSending ? Colors.red.shade300 : Colors.red.shade600,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.red.withValues(alpha: 0.4),
                      blurRadius: 24,
                      spreadRadius: 4,
                    ),
                  ],
                ),
                child: Center(
                  child: _isSending
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text(
                          'SOS',
                          style: TextStyle(color: Colors.white, fontSize: 42, fontWeight: FontWeight.bold),
                        ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text('Hold for 1 second to trigger', style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 32),
            if (_statusMessage != null)
              Card(
                color: _lastSendSucceeded ? Colors.green.shade50 : Colors.orange.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(
                    _statusMessage!,
                    style: TextStyle(
                      color: _lastSendSucceeded ? Colors.green.shade900 : Colors.orange.shade900,
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 24),
            const _ShakeTriggerStatusCard(),
          ],
        ),
      ),
    );
  }
}

/// Displays whether the background accelerometer shake-listener is running.
/// The actual shake detection lives in a native/foreground service
/// (ShakeDetectorService, referenced in AndroidManifest.xml) that calls the
/// same /api/v1/sos/trigger endpoint with trigger_source="shake" when a
/// hard shake pattern is detected — mirroring this screen's manual button flow.
class _ShakeTriggerStatusCard extends StatelessWidget {
  const _ShakeTriggerStatusCard();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            const Icon(Icons.vibration_rounded, color: Colors.green),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Shake-to-alert is running in the background — shake your phone hard '
                'three times to trigger SOS hands-free.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
