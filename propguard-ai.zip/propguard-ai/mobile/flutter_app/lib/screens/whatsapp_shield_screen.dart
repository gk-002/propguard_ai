// whatsapp_shield_screen.dart
// -------------------------------
// Module 2 UI: shows whether the native Android NotificationListenerService
// is active, and lists recently intercepted/flagged messages. This screen
// is intentionally read-mostly — the real interception happens natively
// in WhatsAppSpamListener.kt and posts results to the backend, which this
// screen polls / could subscribe to via websockets in a fuller build.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Bridges to native Android code to check/request Notification Access.
/// Wire this up via a MethodChannel implemented in MainActivity.kt:
///   MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "propguard/notification_access")
class NotificationAccessBridge {
  static const _channel = MethodChannel('propguard/notification_access');

  static Future<bool> isEnabled() async {
    try {
      final result = await _channel.invokeMethod<bool>('isNotificationAccessEnabled');
      return result ?? false;
    } on PlatformException {
      return false;
    }
  }

  static Future<void> openSettings() async {
    try {
      await _channel.invokeMethod('openNotificationAccessSettings');
    } on PlatformException {
      // Swallow — settings screen may already be open, or unsupported OEM.
    }
  }
}

class WhatsAppShieldScreen extends StatefulWidget {
  const WhatsAppShieldScreen({super.key});

  @override
  State<WhatsAppShieldScreen> createState() => _WhatsAppShieldScreenState();
}

class _WhatsAppShieldScreenState extends State<WhatsAppShieldScreen> {
  bool _shieldActive = false;
  bool _checking = true;

  // Demo data — in production, fetch from a
  // GET /api/v1/interceptor/history?user_id=... endpoint (not shown in
  // this blueprint; trivial addition to routers/interceptor.py).
  final List<_FlaggedMessage> _recentFlags = const [
    _FlaggedMessage(
      sender: 'Unknown +91 98xxxxxxxx',
      preview: '"Guaranteed returns on plot booking, transfer advance today!"',
      threatLevel: 'HIGH',
    ),
    _FlaggedMessage(
      sender: 'Broker - Rahul',
      preview: '"Limited time offer, pay token amount to block the flat."',
      threatLevel: 'MEDIUM',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _checkShieldStatus();
  }

  Future<void> _checkShieldStatus() async {
    setState(() => _checking = true);
    final enabled = await NotificationAccessBridge.isEnabled();
    setState(() {
      _shieldActive = enabled;
      _checking = false;
    });
  }

  Color _levelColor(String level) {
    switch (level) {
      case 'CRITICAL':
        return Colors.red.shade700;
      case 'HIGH':
        return Colors.deepOrange;
      case 'MEDIUM':
        return Colors.amber.shade800;
      default:
        return Colors.green.shade700;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('WhatsApp/SMS Shield')),
      body: RefreshIndicator(
        onRefresh: _checkShieldStatus,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              color: _shieldActive ? Colors.green.shade50 : Colors.red.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Icon(
                      _shieldActive ? Icons.verified_user_rounded : Icons.gpp_bad_rounded,
                      color: _shieldActive ? Colors.green.shade700 : Colors.red.shade700,
                      size: 36,
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _checking
                                ? 'Checking shield status…'
                                : (_shieldActive ? 'Shield ACTIVE' : 'Shield INACTIVE'),
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _shieldActive
                                ? 'PropGuard is monitoring WhatsApp/SMS notifications for scams.'
                                : 'Grant Notification Access so PropGuard can scan incoming messages.',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (!_shieldActive && !_checking) ...[
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: NotificationAccessBridge.openSettings,
                icon: const Icon(Icons.settings_rounded),
                label: const Text('Enable Notification Access'),
              ),
            ],
            const SizedBox(height: 24),
            Text('Recently Flagged Messages', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (_recentFlags.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: Text('No suspicious messages detected yet.')),
              )
            else
              ..._recentFlags.map(
                (flag) => Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: _levelColor(flag.threatLevel),
                      child: const Icon(Icons.priority_high_rounded, color: Colors.white),
                    ),
                    title: Text(flag.sender),
                    subtitle: Text(flag.preview),
                    trailing: Chip(
                      label: Text(flag.threatLevel, style: const TextStyle(color: Colors.white, fontSize: 11)),
                      backgroundColor: _levelColor(flag.threatLevel),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _FlaggedMessage {
  final String sender;
  final String preview;
  final String threatLevel;
  const _FlaggedMessage({required this.sender, required this.preview, required this.threatLevel});
}
