// api_service.dart
// ------------------
// Single client for all PropGuard backend calls. Every request attaches
// the current Firebase ID token as a Bearer header, per the PRD auth flow:
//
//   Mobile App --(1. Firebase Auth)--> Firebase
//   Mobile App --(2. Authorization: Bearer <JWT>)--> FastAPI Proxy Backend
//
// Backend base URL is set at build/run time:
//   flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8000

import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'auth_service.dart';

class ApiService {
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000', // Android emulator -> host loopback
  );

  static const Duration _timeout = Duration(seconds: 30);

  static Future<Map<String, String>> _authHeaders({String? contentType}) async {
    final token = await AuthService.instance.idToken;
    if (token == null) {
      throw ApiException(statusCode: 401, message: 'Not signed in — please log in again.');
    }
    return {
      'Authorization': 'Bearer $token',
      if (contentType != null) 'Content-Type': contentType,
    };
  }

  // ------------------------------------------------------------------
  // User profile
  // ------------------------------------------------------------------

  static Future<Map<String, dynamic>> getProfile() async {
    final headers = await _authHeaders();
    final response = await http
        .get(Uri.parse('$baseUrl/api/v1/users/me'), headers: headers)
        .timeout(_timeout);
    return _decodeOrThrow(response);
  }

  static Future<Map<String, dynamic>> upsertProfile({
    required String fullName,
    required List<Map<String, String>> emergencyContacts,
  }) async {
    final headers = await _authHeaders(contentType: 'application/json');
    final response = await http
        .put(
          Uri.parse('$baseUrl/api/v1/users/me'),
          headers: headers,
          body: jsonEncode({
            'full_name': fullName,
            'emergency_contacts': emergencyContacts,
          }),
        )
        .timeout(_timeout);
    return _decodeOrThrow(response);
  }

  // ------------------------------------------------------------------
  // Module 1 — Property document audit
  // ------------------------------------------------------------------

  static Future<Map<String, dynamic>> auditProperty({
    required File file,
    required String documentType,
  }) async {
    final token = await AuthService.instance.idToken;
    if (token == null) {
      throw ApiException(statusCode: 401, message: 'Not signed in — please log in again.');
    }

    final uri = Uri.parse('$baseUrl/api/v1/property/audit');
    final request = http.MultipartRequest('POST', uri)
      ..headers['Authorization'] = 'Bearer $token'
      ..fields['document_type'] = documentType
      ..files.add(await http.MultipartFile.fromPath('file', file.path));

    final streamed = await request.send().timeout(_timeout);
    final response = await http.Response.fromStream(streamed);
    return _decodeOrThrow(response);
  }

  // ------------------------------------------------------------------
  // Module 2 — Interceptor re-scan
  // ------------------------------------------------------------------

  static Future<Map<String, dynamic>> scanMessage({
    required String sourceApp,
    String? senderLabel,
    required String messageText,
  }) async {
    final headers = await _authHeaders(contentType: 'application/json');
    final response = await http
        .post(
          Uri.parse('$baseUrl/api/v1/interceptor/scan'),
          headers: headers,
          body: jsonEncode({
            'source_app': sourceApp,
            'sender_label': senderLabel,
            'message_text': messageText,
          }),
        )
        .timeout(_timeout);
    return _decodeOrThrow(response);
  }

  // ------------------------------------------------------------------
  // Module 3 — Emergency SOS
  // ------------------------------------------------------------------

  static Future<Map<String, dynamic>> triggerSos({
    required double latitude,
    required double longitude,
    required String triggerSource, // "button" | "shake" | "manual"
  }) async {
    final headers = await _authHeaders(contentType: 'application/json');
    final response = await http
        .post(
          Uri.parse('$baseUrl/api/v1/sos/trigger'),
          headers: headers,
          body: jsonEncode({
            'latitude': latitude,
            'longitude': longitude,
            'trigger_source': triggerSource,
          }),
        )
        .timeout(_timeout);
    return _decodeOrThrow(response);
  }

  static Map<String, dynamic> _decodeOrThrow(http.Response response) {
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return body;
    }
    final detail = body['detail']?.toString() ?? 'Unknown error';
    throw ApiException(statusCode: response.statusCode, message: detail);
  }
}

class ApiException implements Exception {
  final int statusCode;
  final String message;
  ApiException({required this.statusCode, required this.message});

  @override
  String toString() => 'ApiException($statusCode): $message';
}
