// shake_detector_service.dart
// -------------------------------
// Module 3: Hardware shake trigger.
// Listens to the accelerometer via `sensors_plus` and fires an SOS
// automatically when it detects a hard, repeated shake pattern — no
// button press needed. Start this once (e.g. in main.dart's initState
// or a background isolate) and it runs for the app's lifetime.
//
// NOTE: For true background operation while the app is fully closed,
// pair this with the native Android foreground service declared in
// AndroidManifest.xml (com.propguard.safety.ShakeDetectorService) using
// a platform channel — this Dart version covers foreground/backgrounded-
// but-alive operation, which is sufficient for most emergency-app UX
// patterns and avoids the stricter background-sensor OS restrictions.

import 'dart:async';
import 'dart:math';
import 'package:sensors_plus/sensors_plus.dart';
import 'api_service.dart';
import 'package:geolocator/geolocator.dart';

class ShakeDetectorService {
  ShakeDetectorService({
    this.shakeThresholdGravity = 2.7,
    this.shakeCountRequired = 3,
    this.shakeWindow = const Duration(milliseconds: 1500),
  });

  final double shakeThresholdGravity;
  final int shakeCountRequired;
  final Duration shakeWindow;

  StreamSubscription<AccelerometerEvent>? _subscription;
  int _shakeCount = 0;
  DateTime? _firstShakeTime;
  bool _cooldownActive = false;

  void start() {
    _subscription = accelerometerEventStream().listen(_onAccelerometerEvent);
  }

  void stop() {
    _subscription?.cancel();
    _subscription = null;
  }

  void _onAccelerometerEvent(AccelerometerEvent event) {
    if (_cooldownActive) return;

    // Compute gravity-normalized magnitude; > ~2.7g repeated quickly
    // indicates a deliberate hard shake rather than normal handling.
    const double gravityEarth = 9.80665;
    final double gX = event.x / gravityEarth;
    final double gY = event.y / gravityEarth;
    final double gZ = event.z / gravityEarth;
    final double gForce = sqrt(gX * gX + gY * gY + gZ * gZ);

    if (gForce <= shakeThresholdGravity) return;

    final now = DateTime.now();
    _firstShakeTime ??= now;

    if (now.difference(_firstShakeTime!) > shakeWindow) {
      // Window expired — restart the count from this shake.
      _firstShakeTime = now;
      _shakeCount = 1;
      return;
    }

    _shakeCount++;
    if (_shakeCount >= shakeCountRequired) {
      _shakeCount = 0;
      _firstShakeTime = null;
      _fireShakeSos();
    }
  }

  Future<void> _fireShakeSos() async {
    _cooldownActive = true;
    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
      );
      await ApiService.triggerSos(
        latitude: position.latitude,
        longitude: position.longitude,
        triggerSource: 'shake',
      );
    } catch (_) {
      // Swallow — a failed shake trigger shouldn't crash the app; the user
      // still has the manual SOS button as a fallback.
    } finally {
      // 30s cooldown prevents repeated accidental triggers from continued shaking.
      await Future.delayed(const Duration(seconds: 30));
      _cooldownActive = false;
    }
  }
}
